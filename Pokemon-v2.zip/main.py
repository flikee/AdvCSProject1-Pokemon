import random
from colorama import Fore

# creates list of pokemon & health values in order
Pokemon = ["Pikachu", "Charizard", "Venusaur", "Blastoise", "Snorlax", "Mewtwo", "Dragonite"] 

# askes for player names
namep1 = input(f"{Fore.RED}Player 1{Fore.WHITE}, what is your name? ")
namep2 = input(f"{Fore.BLUE}Player 2{Fore.WHITE}, what is your name? ")

# prints out list of pokemon with number labeling
print(f"{Fore.GREEN}Pokemon options:{Fore.WHITE}")
for i in range(len(Pokemon)):
  print(f"{i+1}. {Pokemon[i]}")

#asks the player to select their pokemon; if invalid, print invalid input. asks if ready after.
ready = False
while not ready:
  p1pokemon = 0
  p2pokemon = 0
  while p1pokemon < 1 or p1pokemon > 7:
    try: 
      p1pokemon = int(input(f"{Fore.RED}{namep1}{Fore.WHITE}, pick your Pokemon (#): "))
      if p1pokemon < 1 or p1pokemon > 7:
        print("Invalid input.")
    except ValueError:
      print("Invalid input.")
  while p2pokemon < 1 or p2pokemon > 7:
    try: 
      p2pokemon = int(input(f"{Fore.BLUE}{namep2}{Fore.WHITE}, pick your  Pokemon (#): "))
      if p2pokemon < 1 or p2pokemon > 7:
        print("Invalid input.")
    except ValueError:
      print("Invalid input.")
  print(f"{Fore.RED}{namep1}'s Pokemon: {Pokemon[p1pokemon-1]}{Fore.WHITE}")
  print(f"{Fore.BLUE}{namep2}'s Pokemon: {Pokemon[p2pokemon-1]}{Fore.WHITE}")
  ready = int(input("Ready? (0 = No, 1 = Yes): ")) == 1

# function to set health based of pokemon for each player
def set_health(player):
  health = [180, 256, 260, 258, 500, 300, 350]
  return health[player-1]

# function to set moveset based of pokemon for each player
def set_moves(player):
  if player == 1:
    return ["Spark: Random(1-10) * 3", "Double Tail: Random(0-2) * 20", "Thunderbolt: 0"]
  elif player == 2:
    return ["Flamethrower: 15", "Fire Spin: Random(0-3) * 10", "Dragon Breath: Random(0-30) * 1"]
  elif player == 3:
    return ["Vine Whip: 15", "Poison Powder: Random(0-30) * 1", "Razor Leaf: Random(0-3) * 10"]
  elif player == 4:
    return ["Rain Dance: Random(0-30) * 1", "Hydro Pump: Random(0-3) * 10", "Water Gun: 15"]
  elif player == 5:
    return ["Last Resort: Random(-1,1) * 100", "Belly Drum: Random(0-5) * 5", "Fling: 10"]
  elif player == 6:
    return ["Psychic: Random(0-7) * 5", "Confusion: Random(0-1) * 50", "Aura Sphere: Random(1-15) * 2"]
  elif player == 7:
    return ["Dragon Tail: Random(0-30) * 1", "Superpower: Random(0-2) * 15", "Hyper Beam: 15"]

# function to set damage per move based of pokemon for each player
def move_dmg(player):
  if player == 1:
    return [3*random.randint(1, 10), 20*random.randint(0,2), 20]
  elif player == 2:
    return [15, 10*random.randint(0,3), 1*random.randint(0,30)]
  elif player == 3:
    return [15, 1*random.randint(0,30), 10*random.randint(0,3)]
  elif player == 4:
    return [1*random.randint(0,30), 10*random.randint(0,3), 15]
  elif player == 5:
    return [100*random.randint(-1,1), 5*random.randint(0, 5), 10]
  elif player == 6:
    return [4*random.randint(0, 7), 50*random.randint(0,1), 2*random.randint(1,15)]
  elif player == 7:
    return [1*random.randint(0,30), 15*random.randint(0,2), 15]

# sets all variables needed
p1moves = set_moves(p1pokemon)
p1movedmg = move_dmg(p1pokemon)
p1maxhealth = set_health(p1pokemon)
p1currenthealth = set_health(p1pokemon)
p2moves = set_moves(p2pokemon)
p2movedmg = move_dmg(p2pokemon)
p2maxhealth = set_health(p2pokemon)
p2currenthealth = set_health(p2pokemon)
dmg = 0
turn = random.randint(1,2)
death = False

# asks for which move
def ask_move():
  move = 0
  while move < 1 or move > 3:
    try: 
      move = int(input("Pick a move (#): "))
      if move < 1 or move > 3:
        print("Invalid input.")
    except ValueError:
      print("Invalid input.")
  return move

# starts the turn/precombat phase; based on turn, lists out moves and asks for move input
def start_turn(x):
  global p1movedmg
  global p2movedmg
  global dmg
  p1movedmg = move_dmg(p1pokemon)
  p2movedmg = move_dmg(p2pokemon)
  print("")
  if x % 2 != 0:
    print(f"{Fore.RED}{namep1}'s{Fore.WHITE} turn.")
    print("")
    for i in range(3):
      print(f"{i+1}. {p1moves[i]}")
    dmg = p1movedmg[ask_move()-1]
  else:
    print(f"{Fore.BLUE}{namep2}'s{Fore.WHITE} turn.")
    print("")
    for i in range(3):
      print(f"{i+1}. {p2moves[i]}")
    dmg = p2movedmg[ask_move()-1]

# shows each players health, changing color based off what % of their total health they have left
def show_health():
  if p1currenthealth <= (p1maxhealth/3):
    print(f"{Fore.RED}{Pokemon[p1pokemon-1]} HP: {Fore.RED}{p1currenthealth}/{p1maxhealth}{Fore.WHITE}")
  elif p1currenthealth <= ((p1maxhealth/3)*2):
    print(f"{Fore.RED}{Pokemon[p1pokemon-1]} HP: {Fore.YELLOW}{p1currenthealth}/{p1maxhealth}{Fore.WHITE}")
  else:
    print(f"{Fore.RED}{Pokemon[p1pokemon-1]} HP: {Fore.GREEN}{p1currenthealth}/{p1maxhealth}{Fore.WHITE}")
    #################
  if p2currenthealth <= (p2maxhealth/3):
    print(f"{Fore.BLUE}{Pokemon[p2pokemon-1]} HP: {Fore.RED}{p2currenthealth}/{p2maxhealth}{Fore.WHITE}")
  elif p2currenthealth <= ((p2maxhealth/3)*2):
    print(f"{Fore.BLUE}{Pokemon[p2pokemon-1]} HP: {Fore.YELLOW}{p2currenthealth}/{p2maxhealth}{Fore.WHITE}")
  else:
    print(f"{Fore.BLUE}{Pokemon[p2pokemon-1]} HP: {Fore.GREEN}{p2currenthealth}/{p2maxhealth}{Fore.WHITE}")

# post combat phase; deals damage, prints out results
def post_combat(x):
  global p1currenthealth
  global p2currenthealth
  global dmg
  print("")
  if x % 2 != 0:
    p2currenthealth -= dmg
    if p2currenthealth < 0:
      p2currenthealth = 0
    print(f"{Fore.RED}{namep1}'s {Pokemon[p1pokemon-1]}{Fore.WHITE} dealt {dmg} damage to {Fore.BLUE}{namep2}'s {Pokemon[p2pokemon-1]}{Fore.WHITE}!")
  else:
    p1currenthealth -= dmg
    if p1currenthealth < 0:
      p1currenthealth = 0
    print(f"{Fore.BLUE}{namep2}'s {Pokemon[p2pokemon-1]}{Fore.WHITE} dealt {dmg} damage to {Fore.RED}{namep1}'s {Pokemon[p1pokemon-1]}{Fore.WHITE}!")
  
  show_health()
  if p1currenthealth <= 0 and p2currenthealth <= 0:
    print("Game over. It is a draw.")
    death = True
    exit()
  elif p2currenthealth <= 0:
    print(f"Game over. {Fore.RED}{namep1}{Fore.WHITE} has won!")
    death = True
    exit()
  elif p1currenthealth <= 0:
    print(f"Game over. {Fore.BLUE}{namep2}{Fore.WHITE} has won!")
    death = True
    exit()

# game loop
while not death:
  start_turn(turn)
  post_combat(turn)
  turn += 1